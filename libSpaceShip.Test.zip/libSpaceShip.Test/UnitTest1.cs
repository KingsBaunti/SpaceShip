using System;
using Xunit;
using ds.test.impl;

namespace libSpaceShip.Test
{
    public class LibRowTest
    {
        [Fact]
        public void SubtractionRunTest()
        {
            IPlugin sub = new Subtraction();

            int result = sub.Run(1, 1);
            Assert.Equal(0, result);
            result = sub.Run(1, 10);
            Assert.Equal(-9, result);
        }
        [Fact]
        public void RowRunTest()
        {
            Row row1 = new Row();
            Assert.Equal(64, row1.Run(8));
            IPlugin row = new Row();

            int result = row.Run(0, 2);
            Assert.Equal(0, result);
            result = row.Run(2, 3);
            Assert.Equal(8, result);
        }
        [Fact]
        public void SumRunTest()
        {

            IPlugin sum = new Sum();

            int result = sum.Run(1, 1);
            Assert.Equal(2, result);
            result = sum.Run(2, 2);
            Assert.Equal(4, result);
            result = sum.Run(3, 3);
            Assert.Equal(6, result);
        }
        [Fact]
        public void NameTest()
        {
            IPlugin nameRow = new Row();
            string resultRow = nameRow.PluginName;
            Assert.Equal("Row", resultRow);
            IPlugin nameSum = new Sum();
            string resultSum = nameSum.PluginName;
            Assert.Equal("Sum", resultSum);
        }
        [Fact]
        public void PlaginFactoryTest()
        {
            PluginFactory pf = new Plugins();

            Assert.Equal(3, pf.PluginsCount);
            string[] getPluginsNames = { "Row", "Sum", "Subtraction" };
            Assert.Equal(getPluginsNames, pf.GetPluginsNames);
            Assert.Equal("Row", pf.GetPluginsNames[0]);
            Assert.Equal("Sum", pf.GetPluginsNames[1]);
            Assert.Equal("Subtraction", pf.GetPluginsNames[2]);

            IPlugin row = new Row();
            Assert.Equal(row.PluginName, pf.GetPlugin("Row").PluginName);
            IPlugin sum = new Sum();
            Assert.Equal(sum.PluginName, pf.GetPlugin("Sum").PluginName);
            IPlugin subtraction = new Subtraction();
            Assert.Equal(subtraction.PluginName, pf.GetPlugin("Subtraction").PluginName);
            Assert.Null(pf.GetPlugin("dasdasd"));

        }
        [Fact]
        public void PlaginImageTest()
        {

            IPlugin row = new Row();
            Assert.NotNull(row.Image);
            IPlugin sum = new Sum();
            Assert.NotNull(sum.Image);
            IPlugin sub = new Subtraction();
            Assert.NotNull(sub.Image);
        }
    }
}
